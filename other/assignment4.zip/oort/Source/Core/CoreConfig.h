#pragma once

/* CMake Default Variables */
#define CMAKE_VERSION "${CMAKE_VERSION}"
#define CMAKE_SYSTEM "${CMAKE_SYSTEM}"
#define CMAKE_SYSTEM_NAME "${CMAKE_SYSTEM_NAME}"
#define CMAKE_SYSTEM_PROCESSOR "${CMAKE_SYSTEM_PROCESSOR}"
#define CMAKE_CXX_COMPILER_ID "${CMAKE_CXX_COMPILER_ID}"

/* Project variables */

#define PROJECT_NAME "Oort"

/* Any other variables defined in your CMakeLists.txt before configure_file 
 * can be used here.
 * See http://www.cmake.org/cmake/help/v3.1/command/configure_file.html
 */
