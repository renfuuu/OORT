#include "GameManager.h"
GameManager::GameManager(void) {
}
GameManager::~GameManager(void) {
}